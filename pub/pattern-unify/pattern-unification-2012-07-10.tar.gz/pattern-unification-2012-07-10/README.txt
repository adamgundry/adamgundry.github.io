This is the source code accompanying 

A tutorial implementation of dynamic pattern unification
by Adam Gundry and Conor McBride

10th July 2012


The algorithm presented in the paper is in the file Unify.lhs. Look at
the file Test.lhs to see how to invoke it (via GHCi). Note that a
recent version of GHC is required, with the unbound library and SHE
preprocessor (http://personal.cis.strath.ac.uk/conor.mcbride/pub/she/).

